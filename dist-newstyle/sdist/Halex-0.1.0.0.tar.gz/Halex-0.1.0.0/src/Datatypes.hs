module Datatypes where

---- Data Types ----

-- A Game of Halex.
data HalexGame = HalexGame
    {
        player          :: Player,          -- The Player character.
        staticEnv       :: [Environment], -- A 2D array of static environment objects.
        dynamicEnv      :: [Environment], -- A 2D array of dynamic environment objects.
        input           :: S.Set Key        -- The set of user input currently active.
    }

-- The Player Character.
data Player = Player 
    {
        playerIdle      :: [Picture],       -- The list of sprite frames for the Player's idle animation.
        playerWalk      :: [[Picture]],     -- The list of sprite frames for the Player's walk animation.
        playerFrame     :: Int,             -- The current frame of the animation.
        playerDelta     :: Int,             -- The counter until the next frame can advance.
        playerX         :: Int,             -- The Player's x-coordinate.
        playerY         :: Int,             -- The Player's y-coordinate.
        playerSpeed     :: Int,             -- The Player's movement speed.
        playerDirection :: Direction,       -- The Player's current direction.
        playerMoving    :: Bool             -- Determines whether the Player is walking.
    }

-- The Eight Cardinal Directions.
data Direction = North | South | East | West | Northeast | Northwest | Southeast | Southwest deriving (Enum)

-- Static Objects that Compose a Level.
data StaticEnvironment = StaticEnvironment
    {
        senvSprite      :: Picture,         -- The sprite for the object.
        senvX           :: Int,             -- The object's x-coordinate.
        senvY           :: Int,             -- The object's y-coordinate.
        senvType        :: EnvType          -- The class of environment to which this object belongs.
    }

-- Animated Objects that Compose a Level.
data DynamicEnvironment = DynamicEnvironment
    {
        denvAnim        :: [Picture],       -- The list of sprite frames for the object's animation.
        denvFrame       :: Int,             -- The current frame of the animation.
        denvDelta       :: Int,             -- The counter until the next frame can advance.
        denvX           :: Int,             -- The object's x-coordinate.
        denvY           :: Int,             -- The object's y-coordinate.
        denvType        :: EnvType          -- The class of environment to which this object belongs.
    }

-- The Types of Environment.
data EnvType = Terrain                      -- Ground that can be walked on but never walked off.
             | Structure                    -- Objects on the Ground that cannot be walked through.
             | Decoration                   -- Objects on the Ground that can be walked on.
             | Setpiece                     -- Special decorations that are very large.
             | Exit                         -- Portals that transport the Player between levels.