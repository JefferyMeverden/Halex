module Utility where

-- Returns a specified sprite file loaded into a Picture (if it can be loaded).
loadSprite :: FilePath -> Picture
loadSprite filePath = maybe (text "Error: Could not load file.") id (unsafePerformIO $ loadJuicyPNG filePath)

-- Returns the item at the specified index from a given list (if it can be reached).
getItem :: Int -> [a] -> a 
getItem index list = 
    let get n i (z:zs) = if n == i then z else get n (i + 1) zs
        get n i [] = error ("Error: Item " ++ show n ++ " not found at limit " ++ show i)
    in get index 1 list

-- Returns the list of files in a given directory.
getFilesInDir :: String -> IO [FilePath]
getFilesInDir path = do
    entries <- listDirectory path
    let files = map (\x -> path ++ x) entries
    return files

-- Returns a list of sprites corresponding to a list of files.
loadSprites :: [String] -> [Picture]
loadSprites files = map(\x -> loadSprite x) files
