module Main(main) where


import Data.Bool
import Data.Set as S
import Data.Text.Internal.Read
import Graphics.Gloss
import Graphics.Gloss.Data.ViewPort
import Graphics.Gloss.Interface.Environment
import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Juicy
import System.Directory
import System.IO.Unsafe

import Datatypes
import Utility

---- Functions ----


loadStaticEnvironment :: String -> Int -> Int -> [Picture] -> EnvType -> [StaticEnvironment] -> [StaticEnvironment]
loadStaticEnvironment [] x y sprites envtype output = output
loadStaticEnvironment (z:zs) x y anims envtype output =
    case z of 
        '\n'    ->
            loadStaticEnvironment zs 0  (y - 64) sprites envtype output
        '0'     ->
            loadStaticEnvironment zs (x + 64) y sprites envtype output
        _       ->
            let tile = StaticEnvironment (getItem (hexDigitToInt(z)) sprites) x y envtype
            in loadStaticEnvironment zs (x + 64) y sprites envtype (output ++ [tile])

loadDynamicEnvironment :: String -> Int -> Int -> [[Picture]] -> EnvType -> [DynamicEnvironment] -> [DynamicEnvironment]
loadDynamicEnvironment [] x y anims envtype output = output
loadDynamicEnvironment (z:zs) x y anims envtype output =
        case z of 
            '\n'    ->
                loadDynamicEnvironment zs 0 (y - 64) anims envtype output
            '0'     -> 
                loadDynamicEnvironment zs (x + 64) y anims envtype output
            _       ->
                let tile = DynamicEnvironment (getItem (hexDigitToInt(z)) anims) 1 x y envtype
                in loadDynamicEnvironment zs (x + 64) y anims envtype (output ++ [tile])

animateDynamicEnvironment :: [DynamicEnvironment] -> [DynamicEnvironment] -> [DynamicEnvironment]
animateDynamicEnvironment [] output = output
animateDynamicEnvironment (z:zs) output =
    case z of
        DynamicEnvironment anim frame delta x y envtype ->
            if (delta > 0) then
                animateDynamicEnvironment zs (output ++ [DynamicEnvironment anim frame (delta - 1) x y envtype])
            else 
                if (frame > length(anim)) then animateDynamicEnvironment zs (output ++ [DynamicEnvironment anim 1 5 x y envtype])
                else animateDynamicEnvironment zs (output ++ [DynamicEnvironment anim (frame + 1) 5 x y envtype])

moveStaticEnvironment :: [StaticEnvironment] -> Int -> Int -> [StaticEnvironment] -> [StaticEnvironment]
moveStaticEnvironment [] deltaX deltaY output = output
moveStaticEnvironment (z:zs) deltaX deltaY output =
    case z of
        StaticEnvironment sprite x y envtype ->
            moveStaticEnvironment zs deltaX deltaY (output ++ [(StaticEnvironment sprite (x + deltaX) (y + deltaY) envtype)])

moveDynamicEnvironment :: [DynamicEnvironment] -> Int -> Int -> [DynamicEnvironment] -> [DynamicEnvironment]
moveDynamicEnvironment [] deltaX deltaY output = output
moveDynamicEnvironment (z:zs) deltaX deltaY output =
    case z of
        DynamicEnvironment anim frame delta x y envtype ->
            moveDynamicEnvironment zs deltaX deltaY (output ++ [(DynamicEnvironment anim frame delta (x + deltaX) (y + deltaY) envtype)])

drawStaticEnvironment :: [StaticEnvironment] -> [Picture] -> [Picture]
drawStaticEnvironment [] output = output
drawStaticEnvironment (z:zs) output =
    case z of
        StaticEnvironment sprite x y envtype -> 
            let translatedSprite = translate (fromIntegral(x)) (fromIntegral(y)) (sprite)
            in drawStaticEnvironment zs (output ++ [translatedSprite])

drawDynamicEnvironment :: [DynamicEnvironment] -> [Picture] -> [Picture]
drawDynamicEnvironment [] output = output
drawDynamicEnvironment (z:zs) output = 
    case z of
        DynamicEnvironment anim frame delta x y envtype ->
            let currentSprite = getItem frame anim
                translatedSprite = translate (fromIntegral(x)) (fromIntegral(y)) (currentSprite)
            in  drawDynamicEnvironment zs (output ++ [translatedSprite])

animatePlayer :: Player -> Direction -> Bool -> Player
animatePlayer player direction moving = 
    case player of
    Player idleAnims walkAnims frame delta x y speed dr mov ->
        case moving of 
            True    ->
                if (delta > 0) then
                    Player idleAnims walkAnims frame (delta - 1) x y speed direction True 
                else 
                    if (frame > 7) then Player idleAnims walkAnims 1 5 x y speed direction True 
                    else Player idleAnims walkAnims (frame + 1) 5 x y speed direction True
            False   ->      Player idleAnims walkAnims frame delta x y speed dr False 

--Returns a list of Pictures that draw the Player.
drawPlayer :: Player -> [Picture]
drawPlayer player = case player of
    Player idleSprites walkAnims frame delta x y speed direction moving ->
        case moving of
            True    ->
                let currentSprite = getItem frame (getItem (fromEnum(direction)) (walkAnims))
                    translatedSprite = translate (fromIntegral(x)) (fromIntegral(y)) (currentSprite)
                in [translatedSprite]
            False   -> 
                let currentSprite = getItem (fromEnum(direction)) (idleSprites)
                    translatedSprite = translate (fromIntegral(x)) (fromIntegral(y)) (currentSprite)
                in [translatedSprite]

-- Sets the display settings of the game.
window :: Display
window = FullScreen

-- Sets the background of the game.
background :: Color
background = black

-- Sets the frames-per-second of the game.
fps :: Int
fps = 90

-- Returns a Picture of the current state of the game.
render :: HalexGame -> Picture
render game = 
    case game of
        (HalexGame player environment keys) -> pictures ((drawEnvironment environment []) ++ (drawPlayer player))

-- Updates the game by one frame  based on user input and game logic.
update :: Float -> HalexGame -> HalexGame
update seconds game
    | S.member (Char 'w') (input game) && S.member (Char 'd') (input game) = 
        game {environment = updateEnvironment (moveEnvironment (environment game) Northeast 1 []) [],
        player = updatePlayer (player game) Northeast True}
    | S.member (Char 'w') (input game) && S.member (Char 'a') (input game) = 
        game {environment = updateEnvironment (moveEnvironment (environment game) Northwest 1 []) [],
        player = updatePlayer (player game) Northwest True}
    | S.member (Char 's') (input game) && S.member (Char 'd') (input game) = 
        game {environment = updateEnvironment (moveEnvironment (environment game) Southeast 1 []) [],
        player = updatePlayer (player game) Southeast True}
    | S.member (Char 's') (input game) && S.member (Char 'a') (input game) = 
        game {environment = updateEnvironment (moveEnvironment (environment game) Southwest 1 []) [],
        player = updatePlayer (player game) Southwest True}
    | S.member (Char 'w') (input game) = 
        game {environment = updateEnvironment (moveEnvironment (environment game) North 2 []) [],
        player = updatePlayer (player game) North True}
    | S.member (Char 'a') (input game) = 
        game {environment = updateEnvironment (moveEnvironment (environment game) West 2 []) [],
        player = updatePlayer (player game) West True}
    | S.member (Char 's') (input game) = 
        game {environment = updateEnvironment (moveEnvironment (environment game) South 2 []) [],
        player = updatePlayer (player game) South True}
    | S.member (Char 'd') (input game) =
        game {environment = updateEnvironment (moveEnvironment (environment game) East 2 []) [],
        player = updatePlayer (player game) East True}
    | otherwise = 
        game {environment = updateEnvironment (environment game) [],
        player = updatePlayer (player game) North False}

-- Adds user input to the input set in the game object.
manager :: Event -> HalexGame -> HalexGame
manager (EventKey key Down _ _) game  = game {input = S.insert key (input game)}
manager (EventKey key Up _ _) game    = game {input = S.delete key (input game)}
manager _ game                        = game
 

-- Main Function.
main :: IO ()
main = do

    ---- Environment ----

    -- Terrain --

    terrainFiles                <- getFilesInDir "Assets/Sprites/Environment/Terrain/"
    let terrainSprites           = loadSprites terrainFiles

    -- Static Structures --

    staticStructureFiles        <- getFilesInDir "Assets/Sprites/Environment/Structures/Static/"
    let staticStructureSprites   = loadSprites staticStructureFiles

    -- Animated Structures --

    bonfireFiles                <- getFilesInDir "Assets/Sprites/Environment/Structures/Animated/Bonfire/"
    pipeFiles                   <- getFilesInDir "Assets/Sprites/Environment/Structures/Animated/Pipe/"
    treeFiles                   <- getFilesInDir "Assets/Sprites/Environment/Structures/Animated/Tree/"
    wellFiles                   <- getFilesInDir "Assets/Sprites/Environment/Structures/Animated/Well/"

    let dynamicStructureAnims = [
                                    [loadSprites bonfireFiles],
                                    [loadSprites pipeFiles],
                                    [loadSprites treeFiles],
                                    [loadSprites wellFiles]
                                ]

    -- Static Decorations --

    staticDecorationFiles       <- getFilesInDir "Assets/Sprites/Environment/Decoration/Static/"
    let staticDecorationSprites  = loadSprites staticDecorationFiles

    -- Animated Decorations --

    candlesFiles                <- getFilesInDir "Assets/Sprites/Environment/Decoration/Animated/Candles/"
    jackoFiles                  <- getFilesInDir "Assets/Sprites/Environment/Decoration/Animated/JackO/"
    oilFiles                    <- getFilesInDir "Assets/Sprites/Environment/Decoration/Animated/Oil/"
    seanceFiles                 <- getFilesInDir "Assets/Sprites/Environment/Decoration/Animated/Seance/"

    let dynamicDecorationAnims = [
                                    [loadSprites candlesFiles],
                                    [loadSprites jackoFiles],
                                    [loadSprites oilFiles],
                                    [loadSprites seanceFiles]
                                ]

    -- Setpieces --

    setpieceFiles               <- getFilesInDir "Assets/Sprites/Environment/Setpieces/"
    let setpieceSprites          = loadSprites setpieceFiles

    ---- Exits ----

    exitFiles                   <- getFilesInDir "Assets/Sprites/Exits/"
    let exitSprites              = loadSprites exitFiles

    ---- Player ----

    -- Idle --

    playerIdleFiles             <- getFilesInDir "Assets/Sprites/Player/Idle/"
    let playerIdleSprites        = loadSprites playerIdleFiles

    -- Walk --

    playerWalkNFiles            <- getFilesInDir "Assets/Sprites/Player/Walk/N/"
    playerWalkSFiles            <- getFilesInDir "Assets/Sprites/Player/Walk/S/"
    playerWalkEFiles            <- getFilesInDir "Assets/Sprites/Player/Walk/E/"
    playerWalkWFiles            <- getFilesInDir "Assets/Sprites/Player/Walk/W/"
    playerWalkNEFiles           <- getFilesInDir "Assets/Sprites/Player/Walk/NE/"
    playerWalkNWFiles           <- getFilesInDir "Assets/Sprites/Player/Walk/NW/"
    playerWalkSEFiles           <- getFilesInDir "Assets/Sprites/Player/Walk/SE/"
    playerWalkSWFiles           <- getFilesInDir "Assets/Sprites/Player/Walk/SW/"

    let playerWalkAnims =       [
                                    [loadSprites playerWalkNFiles],
                                    [loadSprites playerWalkNFiles],
                                    [loadSprites playerWalkNFiles],
                                    [loadSprites playerWalkNFiles],
                                    [loadSprites playerWalkNFiles],
                                    [loadSprites playerWalkNFiles],
                                    [loadSprites playerWalkNFiles],
                                    [loadSprites playerWalkNFiles]
                                ]





    ---- Create Game Objects ----

    let player = Player playerIdleSprites playerWalkAnims 1 5 0 0 2 North False

    terrainFile <- readFile("Assets/Levels/TestBed/TestBed_Terrain.txt")
    let terrainObjects = loadStaticEnvironment terrainFile 0 (-32) terrainSprites Terrain []

    structureFile <- readFile("Assets/Levels/TestBed/TestBed_Structures.txt")
    let staticStructureObjects = loadStaticEnvironment structureFile 0 0 staticStructureSprites Structure []
    let dynamicStructureObjects = loadDynamicEnvironment structureFile 0 0 dynamicStructureAnims Structure []

    decorationFile <- readFile("Assets/Levels/TestBed/TestBed_Decorations.txt")
    let staticDecorationObjects = loadStaticEnvironment decorationFile 0 0 staticDecorationSprites Decoration []
    let dynamicDecorationObjects = loadDynamicEnvironment decorationFile 0 0 dynamicDecorationAnims Decoration []

    setpieceFile <- readFile("Assets/Levels/TestBed/TestBed_Setpieces.txt")
    let setpieceObjects = loadStaticEnvironment setpieceFile 0 0 setpieceSprites Setpiece []

    let staticEnvironment = terrainObjects ++ setpieceObjects ++ staticStructureObjects ++ staticDecorationObjects
    let dynamicEnvironment = dynamicStructureObjects ++ dynamicDecorationObjects

    let sprites = (drawStaticEnvironment staticEnvironment []) ++ (drawDynamicEnvironment dynamicEnvironment []) ++ (drawPlayer player) 

    ---- Create and Play Game ----

    let game = HalexGame player staticEnvironment dynamicEnvironment   S.empty

    play window background fps game render manager update
